const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'POST required' }, 405);
  const auth = req.headers.get('Authorization') || '';
  const apiKey = Deno.env.get('OPENAI_API_KEY');
  if (!auth.startsWith('Bearer ') || !apiKey) return json({ error: 'Sign in and configure the backend first.' }, 401);
  try {
    const { prompt } = await req.json();
    if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > 2000) return json({ error: 'Enter an image description up to 2,000 characters.' }, 400);
    const response = await fetch('https://api.openai.com/v1/images/generations', { method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: Deno.env.get('OPENAI_IMAGE_MODEL') || 'gpt-image-1', prompt: prompt.trim(), size: '1024x1024' }) });
    const data = await response.json();
    if (!response.ok) return json({ error: data?.error?.message || 'Image generation failed. Check provider access and billing.' }, 502);
    const item = data.data?.[0];
    if (!item?.b64_json && !item?.url) return json({ error: 'No image was returned.' }, 502);
    return json({ image: item.b64_json ? `data:image/png;base64,${item.b64_json}` : item.url });
  } catch { return json({ error: 'Could not generate that image. Please try again.' }, 500); }
});
